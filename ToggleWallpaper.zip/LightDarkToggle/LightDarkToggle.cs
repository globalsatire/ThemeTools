using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ThemeToggler
{
    internal class Program
    {
        private const string PersonalizeKeyPath =
            @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";

        static void Main(string[] args)
        {
            try
            {
                using RegistryKey? key = Registry.CurrentUser.OpenSubKey(PersonalizeKeyPath, writable: true);

                if (key == null)
                {
                    Console.WriteLine("Failed to open registry key.");
                    return;
                }

                int current = GetCurrentTheme(key);
                int newValue = current == 0 ? 1 : 0; // 0 = Dark, 1 = Light

                // Apply theme
                key.SetValue("AppsUseLightTheme", newValue, RegistryValueKind.DWord);
                key.SetValue("SystemUsesLightTheme", newValue, RegistryValueKind.DWord);

                Console.WriteLine(newValue == 0 ? "Switched to Dark Mode" : "Switched to Light Mode");

                // Notify Windows shell & apps
                BroadcastThemeChange();
                BroadcastImmersiveColorChange();

                Console.WriteLine("Theme update broadcast complete.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private static int GetCurrentTheme(RegistryKey key)
        {
            object? value = key.GetValue("AppsUseLightTheme");
            return value is int v ? v : 1;
        }

        // -----------------------------
        // Classic Windows notification
        // -----------------------------
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SendMessageTimeout(
            IntPtr hWnd,
            int Msg,
            IntPtr wParam,
            string lParam,
            int fuFlags,
            int uTimeout,
            out IntPtr lpdwResult);

        private const int HWND_BROADCAST = 0xffff;
        private const int WM_SETTINGCHANGE = 0x001A;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        private static void BroadcastThemeChange()
        {
            SendMessageTimeout(
                (IntPtr)HWND_BROADCAST,
                WM_SETTINGCHANGE,
                IntPtr.Zero,
                "ImmersiveColorSet",
                SMTO_ABORTIFHUNG,
                100,
                out _);
        }

        // ----------------------------------------
        // Modern Windows 10/11 immersive broadcast
        // ----------------------------------------
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool PostMessage(
            IntPtr hWnd,
            int Msg,
            IntPtr wParam,
            IntPtr lParam);

        private const int WM_THEMECHANGED = 0x031A;

        private static void BroadcastImmersiveColorChange()
        {
            // Broadcast WM_THEMECHANGED to all top-level windows
            PostMessage((IntPtr)HWND_BROADCAST, WM_THEMECHANGED, IntPtr.Zero, IntPtr.Zero);
        }
    }
}