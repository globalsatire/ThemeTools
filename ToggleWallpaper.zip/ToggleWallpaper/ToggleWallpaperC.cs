using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;

class Program
{
    [DllImport("user32.dll", SetLastError = true)]
    static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

    [STAThread]
    static void Main()
    {
        string wp1 = @"C:\Wallpapers\wallpaper1.jpg";
        string wp2 = @"C:\Wallpapers\wallpaper2.jpg";

        string current = (string)Registry.GetValue(
            @"HKEY_CURRENT_USER\Control Panel\Desktop",
            "WallPaper",
            ""
        );

        string next = current != null && current.Equals(wp1, StringComparison.OrdinalIgnoreCase)
            ? wp2
            : wp1;

        SystemParametersInfo(20, 0, next, 3);
    }
}